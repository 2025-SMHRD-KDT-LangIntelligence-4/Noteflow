package com.smhrd.model;

public class 모델 {

}
