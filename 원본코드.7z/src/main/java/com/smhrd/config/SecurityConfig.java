package com.smhrd.config;

public class SecurityConfig {

}
